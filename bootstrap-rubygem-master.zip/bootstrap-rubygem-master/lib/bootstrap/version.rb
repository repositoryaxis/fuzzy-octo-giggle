# frozen_string_literal: true

module Bootstrap
  VERSION       = '5.0.0.beta1'
  BOOTSTRAP_SHA = '63f3d939eaceeb84dcc77a7392953bcc8c5bc0a3'
end
